package com.siemens.oam.template.service;

import com.opencsv.CSVReaderBuilder;
import com.siemens.oam.template.dataaccess.entity.Customer;
import com.siemens.oam.template.enums.FileType;
import com.siemens.oam.template.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.*;

import static com.siemens.oam.template.enums.FileType.CSV;
import static com.siemens.oam.template.enums.FileType.EXCEL;

@Service
@RequiredArgsConstructor
@Transactional
public class DataImportService {


    private final CustomerRepository customerRepository;

    public void importCustomerDetails(FileType fileType, MultipartFile file) throws Exception {
        try {
            if(fileType.equals(EXCEL)){
                importCustomerExcel(file);
            } else if (fileType.equals(CSV)) {
                importCustomerCsv(file);
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    public void importCustomerExcel(MultipartFile file) throws Exception {
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();

            // Skip the header row
            if (rowIterator.hasNext()) {
                rowIterator.next();
            }

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                Customer customer = new Customer();
                customer.setName(row.getCell(1).getStringCellValue());
                customer.setNumber(row.getCell(2).getStringCellValue());
                customer.setEmail(row.getCell(3).getStringCellValue());
                customerRepository.save(customer);
                System.out.printf(customer.getId().toString());
            }
        }
        catch (Exception e) {
            throw new Exception("Error importing Excel file: " + e.getMessage());
        }
    }

    public void importCustomerCsv(MultipartFile file) throws Exception {
        try (Reader reader = new InputStreamReader(file.getInputStream())) {
            List<String[]> rows = new CSVReaderBuilder(reader)
                    .withSkipLines(1)
                    .build()
                    .readAll();

            for (String[] row : rows) {
                var x=row[0];
                Customer customer = new Customer();
                customer.setId(Objects.nonNull(x) & !x.isEmpty()?UUID.fromString(row[0]):null);
                customer.setEmail((row[1]));
                customer.setName(row[2]);
                customer.setNumber(row[3]);

                customerRepository.save(customer);
                System.out.printf(customer.getId().toString());
            }
        } catch (Exception e) {
            throw new Exception("Error importing CSV file: " + e.getMessage());
        }
    }
}