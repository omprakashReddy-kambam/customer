package com.siemens.oam.template.service;

import com.siemens.oam.template.dataaccess.entity.Customer;
import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.repository.CustomerRepository;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class CustomerService {
    @Autowired
    public CustomerRepository customerRepo;
    @Autowired
    public ModelMapper modelMapper;
    public CustomerDto createCustomer(CustomerDto customerDTO) {
        modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        var customer = modelMapper.map(customerDTO, Customer.class);
        customerRepo.save(customer);
        return customerDTO;
    }
    @Cacheable("customer")
    public CustomerDto getCustomerById(UUID id) {
        Optional<Customer> optionalCustomer = customerRepo.findById(id);
        modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        if (optionalCustomer.isPresent()) {
            return modelMapper.map(optionalCustomer.get(), CustomerDto.class);
        }
        return null; // no customer found
    }
    @Cacheable("allCustomers")
    public List<CustomerDto> getAllCustomers() {
        List<Customer> customers=customerRepo.findAll();
        modelMapper =new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        return customers.stream().map(entity -> modelMapper.map(entity, CustomerDto.class)).toList();
    }
    @CacheEvict("deleteCustomer")
    public CustomerDto deleteCustomer(UUID id) {
        Optional<Customer> result =customerRepo.findById(id);
        if (result.isPresent()){
            customerRepo.deleteById(id);
            return null;
        }else {
            return null;
        }
    }
    @CachePut("updateCustomer")
    public CustomerDto updateCustomer(CustomerDto customerDto) {
        var customer = customerRepo.findById(customerDto.getId());
        if (customer.isPresent()) {
            var res =modelMapper.map(customerDto, Customer.class);
            customerRepo.save(res);
            return customerDto;
        }
        return null;
    }

}
