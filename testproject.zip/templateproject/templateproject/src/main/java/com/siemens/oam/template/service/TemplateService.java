package com.siemens.oam.template.service;

import com.siemens.oam.template.dataaccess.entity.TemplateEntity;
import com.siemens.oam.template.repository.TemplateJpaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TemplateService {

    private final TemplateJpaRepository templateRepository;

    public void addTemplate(TemplateEntity template) {
        //add logic, checks
        templateRepository.save(template);
    }
}
