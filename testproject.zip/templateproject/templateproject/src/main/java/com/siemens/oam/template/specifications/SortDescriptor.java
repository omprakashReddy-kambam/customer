package com.siemens.oam.template.specifications;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Sort;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SortDescriptor {
    private String field;
    private Sort.Direction direction;
}