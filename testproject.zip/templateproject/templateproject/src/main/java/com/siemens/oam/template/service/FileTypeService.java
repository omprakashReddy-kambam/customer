package com.siemens.oam.template.service;

import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import com.siemens.oam.template.configaration.ExportFieldNames;
import com.siemens.oam.template.dto.ExportCustomerDto;
import com.siemens.oam.template.enums.ModuleName;
import com.siemens.oam.template.pagination.CustomerMappingStrategy;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

import static com.siemens.oam.template.enums.CsvFileName.CSV_CUSTOMER_FILE_NAME;
import static com.siemens.oam.template.enums.ModuleName.CUSTOMER;

@Service
@RequiredArgsConstructor
public class FileTypeService {
    private final ExportFieldNames exportFieldNames;
    private XSSFWorkbook workbook =new XSSFWorkbook();
    private XSSFSheet sheet;
    private static final String CONTENT_DISPOSITION_VALUE_CSV = "attachment; filename=\"%s\"";
    private static final String CONTENT_TYPE = "text/csv";
    private static final String MIME_CONTENT_TYPE = "application/octet-stream";

    public void excelExport(HttpServletResponse response, String fileName) throws IOException {
        response.setContentType("application/octet-stream");
        String headerValue = "attachment; filename=" + fileName;
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, headerValue);
        ServletOutputStream outputStream = response.getOutputStream();
        if (outputStream != null) {
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
        }
    }

    private void writeHeaderLine(ModuleName moduleName) {
        sheet = workbook.createSheet(moduleName.name());
        Row row = sheet.createRow(1);

        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(11);
        style.setFont(font);
        List<String> fields = exportFieldNames.moduleWiseFields(moduleName);
        int i = 0;
        while (i <= (fields.size() - 1)) {
            createCell(row, i, fields.get(i), style);
            i++;
        }
    }

    private void createCell(Row row, int columnCount, Object value, CellStyle style) {
        Cell cell = row.createCell(columnCount);
        if (value instanceof Integer) {
            cell.setCellValue((int) value);
        } else if (value instanceof Boolean) {
            cell.setCellValue((boolean) value);
        } else {
            cell.setCellValue((String) value);
        }
        cell.setCellStyle(style);
    }

    public void customerExcelExport(HttpServletResponse response, List<ExportCustomerDto> dtoList) throws IOException {
        writeHeaderLine(CUSTOMER);
        writeCustomerDataLines(dtoList);
        excelExport(response,"customer.xlsx");
    }

    private void writeCustomerDataLines(List<ExportCustomerDto> dtoList) {
        int rowCount = 1;
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setFontHeight(11);
        style.setFont(font);

        for (ExportCustomerDto dto : dtoList) {
            Row row = sheet.createRow(rowCount++);
            createCell(row, 0, dto.getId(), style);
            createCell(row, 1, dto.getName(), style);
            createCell(row, 2, dto.getNumber(), style);
            createCell(row, 3, dto.getEmail(), style);
        }
    }

    public void customerECsvService(HttpServletResponse response, List<ExportCustomerDto> dtoList) throws IOException, CsvRequiredFieldEmptyException, CsvDataTypeMismatchException {
        response.setContentType(CONTENT_TYPE);
        var headerValue = String.format(CONTENT_DISPOSITION_VALUE_CSV, CSV_CUSTOMER_FILE_NAME.getValue());
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, headerValue);
        CustomerMappingStrategy<ExportCustomerDto> strategy = new CustomerMappingStrategy<>();
        strategy.setType(ExportCustomerDto.class);
        StatefulBeanToCsv<ExportCustomerDto> writer = new StatefulBeanToCsvBuilder<ExportCustomerDto>(response.getWriter())
                .withMappingStrategy(strategy).build();
        writer.write(dtoList);
    }

}


