package com.siemens.oam.template.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExportCustomerDto {

    @CsvBindByName(column = "Id", required = true)
    @CsvBindByPosition(position = 0)
    @JsonSetter(nulls = Nulls.AS_EMPTY)
    private UUID id;

    @CsvBindByName(column = "name", required = true)
    @CsvBindByPosition(position = 1)
    @JsonSetter(nulls = Nulls.AS_EMPTY)
    private String name;

    @CsvBindByName(column = "number", required = true)
    @CsvBindByPosition(position = 2)
    @JsonSetter(nulls = Nulls.AS_EMPTY)
    private String number;

    @CsvBindByName(column = "email", required = true)
    @CsvBindByPosition(position = 3)
    @JsonSetter(nulls = Nulls.AS_EMPTY)
    private String email;

}
