package com.siemens.oam.template.specifications;

public enum JoinOperator {
    OR,
    AND
}
