package com.siemens.oam.template.specifications;

import com.siemens.oam.template.configaration.Filter;
import com.siemens.oam.template.exceptions.QueryOperationException;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;

import java.util.Map;

import static com.siemens.oam.template.dataaccess.QueryOperations.*;



public abstract class AbstractSpecification<T> implements Specification<T> {
    @Override
    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        return buildSpecification().toPredicate(root, query, criteriaBuilder);
    }

    protected abstract Specification<T> buildSpecification();

    protected Predicate executeOperation(Expression expression, CriteriaBuilder criteria, Filter filter) {

        var operator = filter.getOperator();
        var value = filter.getValue();
        switch (operator) {
            case EQUAL:
                return isEqual(expression, criteria, value);
            case NOT_EQUAL:
                return isNotEqual(expression, criteria, value);
            case GREATER_THAN:
                return isGreaterThan(expression, criteria, value);
            case LESS_THAN:
                return isLessThan(expression, criteria, value);
            case GREATER_THAN_OR_EQUAL:
                return isGreaterThanOrEqual(expression, criteria, value);
            case LESS_THAN_OR_EQUAL:
                return isLessThanOrEqual(expression, criteria, value);
            case STARTS_WITH:
                return startsWith(expression, criteria, value);
            case ENDS_WITH:
                return endsWith(expression, criteria, value);
            case CONTAINS:
                return doesContain(expression, criteria, value);
            case NOT_CONTAINS:
                return notContains(expression, criteria, value);
            case IN:
                return inContains(expression, criteria, filter.getId());
            default:
                throw new QueryOperationException(HttpStatus.BAD_REQUEST,QueryOperationException.Messages.OPERATION_NOT_SUPPORTED.with(operator));
        }
    }

    public static Path getPathForColumnName(Root root, Map<String, String> columnsMapping, String columnName) {
        String rawColumn = columnsMapping.get(columnName);
        if (rawColumn == null) {
            throw new com.siemens.oam.template.dataaccess.common.exceptions.FilteringException(HttpStatus.BAD_REQUEST, com.siemens.oam.template.dataaccess.common.exceptions.FilteringException.Messages.FILTERING_COLUMN_NOT_SUPPORTED.with(columnName));
        }
        return getPathForRawColumn(root, rawColumn);
    }

    protected static Path getPathForRawColumn(Root root, String rawColumn) {
        String[] columns = rawColumn.split("\\.");
        Path path = root;
        for (String column : columns) {
            path = path.get(column);
        }
        return path;
    }
}
