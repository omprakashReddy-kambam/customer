package com.siemens.oam.template.enums;

public enum ModuleName {
    CUSTOMER
}
