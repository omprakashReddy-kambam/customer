package com.siemens.oam.template.controller;

import com.siemens.oam.template.enums.FileType;
import com.siemens.oam.template.service.DataImportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RequiredArgsConstructor
@RestController
@RequestMapping("/file")
public class DataImportController {


    private final DataImportService dataImportService;

    @PostMapping("/import")
    public void imporCustomerDetails(@RequestParam FileType fileType,
                                     @RequestParam("file") MultipartFile file) throws Exception {
        dataImportService.importCustomerDetails(fileType, file);
        System.out.println("");
    }
}