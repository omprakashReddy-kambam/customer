package com.siemens.oam.template.infrastructure.rest.request;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.siemens.oam.template.dataaccess.entity.TemplateEntity;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonDeserialize(builder = TemplateRequest.TemplateRequestBuilder.class)
@Builder(toBuilder = true)
public class TemplateRequest {

    String name;
    String description;

    public TemplateEntity toTemplate() {
        return TemplateEntity.builder()
                    .name(this.name)
                    .description(this.description)
                    .build();
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static class TemplateRequestBuilder {

    }
}
