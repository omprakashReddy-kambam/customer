package com.siemens.oam.template.controller;

import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    public CustomerService customerService;
    @PostMapping("/createCustomer")
    public ResponseEntity<CustomerDto> createCustomer(@RequestBody CustomerDto customerDto) {
      var customer=customerService.createCustomer(customerDto);
        return new ResponseEntity<>(customer, HttpStatus.ACCEPTED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerDto> getCustomerById(@PathVariable UUID id) {
        return ResponseEntity.ok(customerService.getCustomerById(id));
//        return new ResponseEntity(customer,HttpStatus.CREATED);
    }
    @GetMapping("/listAll")
    public ResponseEntity<List<CustomerDto>> getAllCustomers() {
        return ResponseEntity.ok(customerService.getAllCustomers());
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<CustomerDto> deleteCustomer(@PathVariable UUID id) {
        return ResponseEntity.ok(customerService.deleteCustomer(id));
    }
    @PutMapping("/{id}")
    public ResponseEntity<CustomerDto> updateCustomer( @RequestBody CustomerDto customerDto) {
        CustomerDto customer= customerService.updateCustomer(customerDto);
        return new ResponseEntity<>(customer,HttpStatus.CREATED);
    }

//    public String updateEmployee(@RequestBody CustomerDto employeeRequest) {
//        return customerService.updateEmployee(employeeRequest);
//    }
}

