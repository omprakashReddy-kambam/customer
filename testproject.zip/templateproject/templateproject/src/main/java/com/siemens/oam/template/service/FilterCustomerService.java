package com.siemens.oam.template.service;

import com.siemens.oam.template.configaration.CustomerSpecification;
import com.siemens.oam.template.dataaccess.entity.Customer;
import com.siemens.oam.template.dataaccess.entity.DataRequest;
import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.dto.PageResponseDto;
import com.siemens.oam.template.exceptions.QueryOperationException;
import com.siemens.oam.template.repository.CustomerRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.siemens.oam.template.pagination.CustomerColumnMapping.getColumnNameOfCatalogDetail;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class FilterCustomerService {
    @Autowired
    private ModelMapper modelMapper;

    private final CustomerRepository customerRepository;
    public PageResponseDto<CustomerDto> customerDetailsFilter(DataRequest dataRequest) {
        modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        List<CustomerDto> dtoList;
        var sortDescriptor = dataRequest.getSort().get(0);
        var sortDirection = sortDescriptor.getDirection();
        var sortFieldName = sortDescriptor.getField();
        var sort = Sort.by(sortDirection, getColumnNameOfCatalogDetail(sortFieldName));
        var pageRequest = PageRequest.of(dataRequest.getPageNumber(), dataRequest.getPageSize(), sort);

        var specification = new CustomerSpecification(dataRequest);
        var list = getBySpecification(specification, pageRequest);

        dtoList = list.getContent().stream().map(obj ->
                modelMapper.map(obj, CustomerDto.class)
        ).toList();

        return PageResponseDto.<CustomerDto>builder()
                .totalNumberOfElements(list.getTotalElements())
                .totalNumberOfPages(list.getTotalPages())
                .data(dtoList)
                .build();
    }
    public Page<Customer> getBySpecification(
            Specification<Customer> specification, Pageable pageable) {
        try {
            return customerRepository.findAll(specification, pageable);
        } catch (InvalidDataAccessApiUsageException exception) {
            log.error("Cannot execute query operation due to : {}", exception.getMessage());
            throw new QueryOperationException(
                    HttpStatus.BAD_REQUEST, QueryOperationException.Messages.OPERATION_NOT_ALLOWED_TO_PERFORM_ON_COLUMN.getMessage());
        }
    }

}
