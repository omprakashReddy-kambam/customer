package com.siemens.oam.template.controller;

import com.siemens.oam.template.dataaccess.entity.DataRequest;
import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.dto.PageResponseDto;
import com.siemens.oam.template.service.FilterCustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
@RequestMapping("/filter/customer")
public  class CustomerFilterController {
    private final FilterCustomerService customerFilterService;
    @PostMapping()
    public ResponseEntity<PageResponseDto<CustomerDto>> customerDetailsFilter(@RequestBody DataRequest dataRequest) {
        return ResponseEntity.ok(customerFilterService.customerDetailsFilter(dataRequest));
    }

}
