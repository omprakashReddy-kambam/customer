package com.siemens.oam.template.infrastructure.rest;

import com.siemens.oam.template.infrastructure.rest.request.TemplateRequest;
import com.siemens.oam.template.service.TemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/template")
public class TemplateController {

    private final TemplateService templateService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void createTemplate(@RequestBody TemplateRequest templateRequest) {
        templateService.addTemplate(templateRequest.toTemplate());
    }
}
