package com.siemens.oam.template.configaration;

//import com.siemens.oam.template.enums.Operators;
import com.siemens.oam.template.enums.Operator;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Collections;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Filter {
    private String field;
    private Operator operator;
    private String value;

    private List<Long> id= Collections.emptyList();
}
