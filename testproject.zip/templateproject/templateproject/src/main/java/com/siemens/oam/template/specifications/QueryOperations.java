package com.siemens.oam.template.dataaccess;

import com.siemens.oam.template.exceptions.QueryOperationException;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class QueryOperations {
        public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        public static final String SQL_CHAR_ANY_POSITION_FORMAT = "%%%s%%";
        public static final String SQL_CHAR_START_POSITION_FORMAT = "%s%%";
        public static final String SQL_CHAR_END_POSITION_FORMAT = "%%%s";

        public static final String SQL_CHAR_FORMAT = "%s";
        public static final String ANY_NUMBER_OF_CHARS_WILDCARD = "*";
        public static final String ANY_SINGLE_CHAR_WILDCARD = "?";
        public static final String SQL_ANY_NUMBER_OF_CHARS_WILDCARD = "%";
        public static final String SQL_ANY_SINGLE_CHAR_WILDCARD = "_";

        private QueryOperations() {
        }

        public static Predicate isEqual(Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.equal(
                    toLowerIfString(expression, criteria), castToColumnType(expression.getJavaType(), value));
        }

        public static Predicate isNotEqual(
                Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.notEqual(
                    toLowerIfString(expression, criteria), castToColumnType(expression.getJavaType(), value));
        }

        public static Predicate isGreaterThan(
                Expression expression, CriteriaBuilder criteriaBuilder, String value) {
            return criteriaBuilder.greaterThan(
                    expression, castToColumnType(expression.getJavaType(), value));
        }

        public static Predicate isLessThan(
                Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.lessThan(expression, castToColumnType(expression.getJavaType(), value));
        }

        public static Predicate isGreaterThanOrEqual(
                Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.greaterThanOrEqualTo(
                    expression, castToColumnType(expression.getJavaType(), value));
        }

        public static Predicate isLessThanOrEqual(
                Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.lessThanOrEqualTo(
                    expression, castToColumnType(expression.getJavaType(), value));
        }

        public static Predicate startsWith(
                Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.like(
                    criteria.lower(expression), reviseWildcardCharsText(SQL_CHAR_START_POSITION_FORMAT, value));
        }

        public static Predicate endsWith(Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.like(
                    criteria.lower(expression), reviseWildcardCharsText(SQL_CHAR_END_POSITION_FORMAT, value));
        }

        public static Predicate doesContain(
                Expression expression, CriteriaBuilder criteria, String value) {
            return criteria.like(
                    criteria.lower(expression), reviseWildcardCharsText(SQL_CHAR_ANY_POSITION_FORMAT, value));
        }

        public static Predicate notContains(
                Expression expression, CriteriaBuilder criteria, String value) {
            List<Predicate> predicates = new ArrayList<>();
            Predicate q1 = criteria.notLike(
                    criteria.lower(expression), reviseWildcardCharsText(SQL_CHAR_ANY_POSITION_FORMAT, value));
            Predicate q2 = criteria.isNull(criteria.lower(expression));
            Predicate q3 = criteria.or(q1, q2);
            predicates.add(q3);
            return predicates.get(0);
        }

        public static Predicate inContains(
                Expression expression, CriteriaBuilder criteria, List<Long> idList) {
            return criteria.in(expression).value(idList);
        }


        private static Comparable castToColumnType(Class columnType, String value) {
            if (value.isEmpty() && value.isBlank())
                return null;
            if (columnType.isAssignableFrom(Integer.class)) {
                return Integer.valueOf(value);
            } else if (Enum.class.isAssignableFrom(columnType)) {
                return Enum.valueOf(columnType, value);
            } else if (columnType.isAssignableFrom(LocalDateTime.class)) {
                return LocalDateTime.parse(value, DateTimeFormatter.ofPattern(DATE_TIME_FORMAT));
            } else if (columnType.isAssignableFrom(Date.class)) {
                return parseDate(value);
            } else if (columnType.isAssignableFrom(String.class)) {
                return reviseWildcardCharsText(SQL_CHAR_FORMAT, value);
            } else if (columnType.isAssignableFrom(Double.class)) {
                return Double.valueOf(value);
            } else if (columnType.isAssignableFrom(boolean.class)) {
                return Boolean.valueOf(value);
            } else if (columnType.isAssignableFrom(Boolean.class)) {
                return Boolean.valueOf(value);
            } else if (columnType.isAssignableFrom(UUID.class)) {
                return UUID.fromString(value);
            } else if (columnType.isAssignableFrom(BigDecimal.class)) {
                return new BigDecimal(value);
            } else {
                throw new QueryOperationException(
                        HttpStatus.BAD_REQUEST,
                        QueryOperationException.Messages.OPERATION_NOT_SUPPORTED.with(columnType));
            }
        }

        private static Expression toLowerIfString(Expression expression, CriteriaBuilder criteria) {
            return expression.getJavaType().isAssignableFrom(String.class)
                    ? criteria.lower(expression)
                    : expression;
        }

        private static Date parseDate(String value) {
            try {
                return new SimpleDateFormat(DATE_TIME_FORMAT).parse(value);
            } catch (ParseException e) {
                throw new QueryOperationException(HttpStatus.BAD_REQUEST, e.getMessage());
            }
        }


        private static String reviseWildcardCharsText(String format, String text) {
            return String.format(
                    format,
                    text.replace(ANY_NUMBER_OF_CHARS_WILDCARD, SQL_ANY_NUMBER_OF_CHARS_WILDCARD)
                            .replace(ANY_SINGLE_CHAR_WILDCARD, SQL_ANY_SINGLE_CHAR_WILDCARD)
                            .toLowerCase());
        }



}


