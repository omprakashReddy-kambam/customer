package com.siemens.oam.template.controller;

import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import com.siemens.oam.template.dataaccess.entity.DataRequest;
import com.siemens.oam.template.enums.FileType;
import com.siemens.oam.template.service.DataExportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.text.ParseException;

@RestController
@RequiredArgsConstructor
@RequestMapping("/file")
public class DataExportController {

    private final DataExportService dataExportService;

    @PostMapping("/export")
    public void exportData(@RequestParam FileType fileType,
                             @RequestBody DataRequest dataRequest) throws IOException,CsvRequiredFieldEmptyException, CsvDataTypeMismatchException {
        dataExportService.export(fileType, dataRequest);
    }
}
