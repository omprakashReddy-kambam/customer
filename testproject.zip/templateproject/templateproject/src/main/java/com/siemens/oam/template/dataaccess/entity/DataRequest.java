package com.siemens.oam.template.dataaccess.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.siemens.oam.template.specifications.CompositeFilter;
import com.siemens.oam.template.specifications.SortDescriptor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import java.util.Collections;
import java.util.List;
import java.util.UUID;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class DataRequest {
    private List<CompositeFilter> filters =Collections.emptyList();;
    private List<SortDescriptor> sort;
    private int pageNumber;
    private int pageSize = 100;
    private List<Long> id= Collections.emptyList();
}
