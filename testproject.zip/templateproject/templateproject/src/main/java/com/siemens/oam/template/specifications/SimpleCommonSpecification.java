package com.siemens.oam.template.specifications;

import com.siemens.oam.template.configaration.Filter;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Map;

public abstract class SimpleCommonSpecification<T> extends AbstractSpecification<T> {
    protected Specification<T> applyFiltering(Specification<T> specification, Map<String, String> supportedColumnsForFiltering
            , List<CompositeFilter> filtersForLevel1) {
        for (var filterForLevel1 : filtersForLevel1) {
            var specificationForCompositeFilter = getSpecificationForCompositeFilter(supportedColumnsForFiltering, filterForLevel1);
            specification = specification.and(specificationForCompositeFilter);
        }
        return specification;
    }

    private Specification<T> getSpecificationForCompositeFilter(Map<String, String> supportedColumnsForFiltering
            , CompositeFilter compositeFilter) {
        var compositeFilters = compositeFilter.getFilters();
        if (compositeFilters == null) {
            return getSpecificationForFilter(supportedColumnsForFiltering, compositeFilter);
        }
        var joinOperator = compositeFilter.getJoinOperator();
        Specification<T> specification = Specification.where(null);

        for (var compositeFilter2 : compositeFilters) {
            if (JoinOperator.AND == joinOperator) {
                var specificationForCompositeFilter = getSpecificationForCompositeFilter(supportedColumnsForFiltering, compositeFilter2);
                specification = specification.and(specificationForCompositeFilter);
            } else if (JoinOperator.OR == joinOperator) {
                var specificationForCompositeFilter = getSpecificationForCompositeFilter(supportedColumnsForFiltering, compositeFilter2);
                specification = specification.or(specificationForCompositeFilter);
            }
        }
        return specification;
    }

    protected Specification<T> getSpecificationForFilter(Map<String, String> supportedColumnsForFiltering, Filter filter) {
        return (root, query, criteria) ->
                executeOperation(getPathForColumnName(root, supportedColumnsForFiltering, filter.getField()), criteria, filter);
    }

}

