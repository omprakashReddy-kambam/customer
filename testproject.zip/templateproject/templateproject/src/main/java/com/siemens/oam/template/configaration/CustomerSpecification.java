package com.siemens.oam.template.configaration;

import com.siemens.oam.template.dataaccess.entity.Customer;
import com.siemens.oam.template.dataaccess.entity.DataRequest;
import com.siemens.oam.template.specifications.SimpleCommonSpecification;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.Map;

import static com.siemens.oam.template.pagination.CustomerColumnMapping.EMAIL;
import static com.siemens.oam.template.pagination.CustomerColumnMapping.NUMBER;
import static com.siemens.oam.template.pagination.CustomerColumnMapping.NAME;
public class CustomerSpecification extends SimpleCommonSpecification<Customer> {
    private static final Map<String, String> SUPPORTED_FILTERING_COLUMNS = Map.of(
            NAME, NAME,
            NUMBER, NUMBER,
            EMAIL, EMAIL);

    private  transient DataRequest dataRequest;

    public CustomerSpecification( DataRequest dataRequest) {
        this.dataRequest = dataRequest;

    }


    protected Specification<Customer> buildSpecification() {
        Specification<Customer> specification = createidSpecification() ;
        return applyFiltering(specification, SUPPORTED_FILTERING_COLUMNS, dataRequest.getFilters());
    }

    private Specification<Customer>createidSpecification()  {
        return Specification
                .where((Root<Customer> root, CriteriaQuery<?> query, CriteriaBuilder criteria) -> null);
        //.where((Root<EmployeeEntity> root, CriteriaQuery<?> query, CriteriaBuilder criteria) -> criteria.equal(root.get("id"), id));
    }
}
