package com.siemens.oam.template.dto;

import lombok.*;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageResponseDto<T> {
    private Integer totalNumberOfPages;
    private Long totalNumberOfElements;
    private List<T> data;

}
