package com.siemens.oam.template.service;

import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import com.siemens.oam.template.dataaccess.entity.DataRequest;
import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.dto.ExportCustomerDto;
import com.siemens.oam.template.dto.PageResponseDto;
import com.siemens.oam.template.enums.FileType;
import com.siemens.oam.template.repository.CustomerRepository;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

import static com.siemens.oam.template.enums.FileType.CSV;
import static com.siemens.oam.template.enums.FileType.EXCEL;

@Service
@RequiredArgsConstructor
public class DataExportService {

    private final CustomerRepository customerRepository;
    private  final FilterCustomerService filterCustomerService;
    private  final FileTypeService fileTypeService;
    private final HttpServletResponse response;

    @Autowired
    ModelMapper modelMapper;

    PageResponseDto<CustomerDto> customers;
    public void export(FileType fileType, DataRequest dataRequest) throws CsvRequiredFieldEmptyException, CsvDataTypeMismatchException, IOException {
        modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

        List<ExportCustomerDto> dtoList;
        dataRequest.setPageSize((int) customerRepository.count());
        customers = filterCustomerService.customerDetailsFilter(dataRequest);
            dtoList=customers.getData().stream().map(obj -> ExportCustomerDto.builder()
               .id(obj.getId())
               .name(obj.getName())
               .number(obj.getNumber())
               .email(obj.getEmail())
                       .build()).toList();
       exportCustomer(response,dtoList,fileType);
    }
    private void exportCustomer(HttpServletResponse response, List<ExportCustomerDto> customerDtoList, FileType fileType) throws IOException, CsvRequiredFieldEmptyException, CsvDataTypeMismatchException {
        if (fileType.equals(EXCEL))
            fileTypeService.customerExcelExport(response, customerDtoList);
        else if (fileType.equals(CSV))
            fileTypeService.customerECsvService(response, customerDtoList);
    }
}