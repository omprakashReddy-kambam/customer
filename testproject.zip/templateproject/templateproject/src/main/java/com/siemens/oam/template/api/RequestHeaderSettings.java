package com.siemens.oam.template.api;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class RequestHeaderSettings {
    public static final String CORRELATION_ID = "vendor";
    public static final String CUSTOMER_ID = "vendor-user";
    public static final Integer TIMEOUT_VALUE = 10000;
}
