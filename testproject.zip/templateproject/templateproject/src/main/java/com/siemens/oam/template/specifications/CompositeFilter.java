package com.siemens.oam.template.specifications;

import com.siemens.oam.template.configaration.Filter;
import lombok.*;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CompositeFilter extends Filter {
    private List<CompositeFilter> filters;
    private JoinOperator joinOperator;
}
