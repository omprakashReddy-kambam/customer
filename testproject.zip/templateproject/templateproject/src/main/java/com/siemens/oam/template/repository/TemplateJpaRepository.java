package com.siemens.oam.template.repository;

import com.siemens.oam.template.dataaccess.entity.TemplateEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.UUID;

@Transactional
public interface TemplateJpaRepository extends JpaRepository<TemplateEntity, UUID> {

}
