package com.siemens.oam.template.dataaccess.common.exceptions;


import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;

@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class FilteringException extends RuntimeException{
    @Getter
    HttpStatus httpStatus;

    public FilteringException(HttpStatus httpStatus, String errorMessage) {
        super(errorMessage);
        this.httpStatus = httpStatus;
    }

    @AllArgsConstructor(access = AccessLevel.PRIVATE)
    public enum Messages {
        INCORRECT_DATA_REQUEST_FORMAT("Incorrect format of data request for filtering"),
        FILTERING_COLUMN_NOT_SUPPORTED("Column [%s] is not supported for filtering"),
        OPERATION_NOT_SUPPORTED_FOR_FILTERING_COLUMN("Operation [%s] is not supported for filtering column [%s]"),
        VALUE_NOT_SUPPORTED_FOR_OPERATION_WITH_FILTERING_COLUMN("Value for operation [%s] with filtering column [%s] is not supported, supported values : %s"),
        NUMBER_OF_VALUES_FOR_OPERATION_WITH_FILTERING_COLUMN_NOT_MATCHING_EXPECTANCY("Number of values for operation [%s] " +
                "with filtering column [%s] not matching expectancy, required number : %s"),
        FILTERING_ERROR("Failed to filter due to an error. Error message is: %s");
        @Getter private final String message;

        @SafeVarargs
        public final <T> String with(T... args) {
            return String.format(message, args);
        }
    }
}
