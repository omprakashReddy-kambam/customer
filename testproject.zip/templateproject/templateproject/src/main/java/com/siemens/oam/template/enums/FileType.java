package com.siemens.oam.template.enums;

public enum FileType {

    EXCEL,
    CSV
}