package com.siemens.oam.template.exceptions;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class SortingColumnNotSupportedException extends RuntimeException {

    @Getter
    HttpStatus httpStatus;

    public SortingColumnNotSupportedException(HttpStatus httpStatus, String errorMessage) {
        super(errorMessage);
        this.httpStatus = httpStatus;
    }

    @AllArgsConstructor(access = AccessLevel.PRIVATE)
    public enum Messages {
        SORTING_COLUMN_NOT_SUPPORTED("Column [%s] is not supported for sorting");

        @Getter private final String message;

        @SafeVarargs
        public final <T> String with(T... args) {
            return String.format(message, args);
        }
    }
}