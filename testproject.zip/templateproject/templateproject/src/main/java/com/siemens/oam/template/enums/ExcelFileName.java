package com.siemens.oam.template.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ExcelFileName {
    EXCEL_CUSTOMER_FILE_NAME("customer.xlsx");
    private final String value;
}
