package com.siemens.oam.template.enums;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter

public enum CsvFileName {
    CSV_CUSTOMER_FILE_NAME("customer.csv");
    private final String value;
}