package com.siemens.oam.template.pagination;

import com.siemens.oam.template.exceptions.SortingColumnNotSupportedException;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

import java.util.Map;

public class CustomerColumnMapping {

    public static final String NAME = "name";
    public static final String NUMBER = "number";
    public static final String EMAIL = "email";

    private static final Map<String, String> customer_DTO_ENTITY_MAPPING = Map.of(
            NAME, NAME,
            EMAIL, EMAIL,
            NUMBER, NUMBER
    );

    private CustomerColumnMapping() {
    }

    public static String getColumnNameOfCatalogDetail(String name) {
        if (StringUtils.isNotEmpty(name) && customer_DTO_ENTITY_MAPPING.containsKey(name)) {
            return customer_DTO_ENTITY_MAPPING.get(name);
        }

        throw new SortingColumnNotSupportedException(HttpStatus.BAD_REQUEST,
                SortingColumnNotSupportedException.Messages.SORTING_COLUMN_NOT_SUPPORTED.with(name));
    }
}