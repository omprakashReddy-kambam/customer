package com.siemens.oam.template.exceptions;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;

@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class QueryOperationException extends RuntimeException{

    @Getter
    HttpStatus httpStatus;

    public QueryOperationException(HttpStatus httpStatus, String errorMessage) {
        super(errorMessage);
        this.httpStatus = httpStatus;
    }

    @AllArgsConstructor(access = AccessLevel.PRIVATE)
    public enum Messages {
        OPERATION_NOT_SUPPORTED("[%s] operation is not supported"),
        OPERATION_NOT_ALLOWED_TO_PERFORM_ON_COLUMN("Could not execute operation or multiple operations due to not compatible value and operation"),
        NUMBER_OF_VALUES_NOT_MATCHING_EXPECTANCY(
                "Number of values for operation [%s] not matching expectancy, required number : %s"),
        COLUMN_TYPE_NOT_SUPPORTED("Column type [%s] is not supported");

        @Getter private final String message;

        @SafeVarargs
        public final <T> String with(T... args) {
            return String.format(message, args);
        }
    }
}

