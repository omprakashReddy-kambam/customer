package com.siemens.oam.template.configaration;

//import com.siemens.oam.template.enums.ModuleName;
import com.siemens.oam.template.enums.ModuleName;
import lombok.RequiredArgsConstructor;
import org.aspectj.apache.bcel.classfile.ModuleMainClass;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RequiredArgsConstructor
@Service
public class ExportFieldNames {
    private static final String ID ="id";
    private static final String NAME = "name";
    private static final  String NUMBER = "number";
    private static final  String EMAIL = "email";


    public List<String> moduleWiseFields(ModuleName moduleName) {
        switch (moduleName) {
            case CUSTOMER:
                return Arrays.asList(ID, NAME, NUMBER, EMAIL);
            default:
                break;
        }
        return new ArrayList<>();
    }
}
