package com.siemens.oam.template.integation;

import com.siemens.oam.template.TemplateApplication;
import com.siemens.oam.template.repository.CustomerRepository;
import com.siemens.oam.template.repository.TestH2Repository;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.util.UriComponentsBuilder;

import static org.apache.hc.core5.http2.H2PseudoRequestHeaders.SCHEME;
import static org.springframework.http.HttpHeaders.HOST;
@ExtendWith(SpringExtension.class)
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = TemplateApplication.class)
//@Sql(scripts = "/sql/truncate_table.sql", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
@Import({IntegrationTestConfiguration.class})
public abstract class AbstractIntegrationTest {

    @Autowired
    protected TestRestTemplate testrestTemplate;
    @Autowired
    protected CustomerRepository customerRepository;
    protected static final String SCHEME = "http";
    protected static final String HOST = "localhost";
    @LocalServerPort
    protected int port;

    public UriComponentsBuilder constructBaseUrl(String basePath){
        return UriComponentsBuilder.newInstance()
                .scheme(SCHEME)
                .host(HOST)
                .port(this.port)
                .pathSegment(basePath);
    }
}
