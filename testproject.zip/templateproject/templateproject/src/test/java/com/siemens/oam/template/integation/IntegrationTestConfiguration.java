package com.siemens.oam.template.integation;

import com.siemens.oam.template.api.RequestHeaderSettings;
import com.siemens.shared.enableoambootstrap.property.HeaderValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;

import java.util.Collections;

@TestConfiguration
public class IntegrationTestConfiguration {

    @Autowired
    private HeaderValidation headerValidation;

    @Bean
    public TestRestTemplate testRestTemplate(HttpHeaders testHttpHeaders) {
        var testRestTemplate = new TestRestTemplate();
        testRestTemplate
                .getRestTemplate()
                .setInterceptors(
                        Collections.singletonList(
                                (request, body, execution) -> {
                                    request.getHeaders().addAll(testHttpHeaders);
                                    return execution.execute(request, body);
                                }));

        return testRestTemplate;
    }

    @Bean
    public HttpHeaders testHttpHeaders() {
        var headers = new HttpHeaders();
        headers.add(headerValidation.getCorrelationIdField(), RequestHeaderSettings.CORRELATION_ID);
        headers.add(headerValidation.getUserIdField(), RequestHeaderSettings.CUSTOMER_ID);
        headers.add(headerValidation.getTimeoutField(), RequestHeaderSettings.TIMEOUT_VALUE.toString());

        return headers;
    }
}
