package com.siemens.oam.template;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.lang.ArchRule;
import org.junit.jupiter.api.Test;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

public class ArchitectureTest {

    @Test
    void givenDependencyRule_notImportInfrastructureInService() {
        JavaClasses importedClasses = new ClassFileImporter()
                .importPackages("com.siemens.oam.template");

        ArchRule rule = noClasses().that()
                .resideInAPackage("..service..")
                .should().dependOnClassesThat().resideInAPackage("..infrastructure..");

        rule.check(importedClasses);
    }

    @Test
    void givenDependencyRule_notImportInfrastructureInDomain() {
        JavaClasses importedClasses = new ClassFileImporter()
                .importPackages("com.siemens.oam.template");

        ArchRule rule = noClasses().that()
                .resideInAPackage("..dataaccess..")
                .should().dependOnClassesThat().resideInAPackage("..infrastructure..");

        rule.check(importedClasses);
    }

    @Test
    void givenDependencyRule_notImportServiceInDomain() {
        JavaClasses importedClasses = new ClassFileImporter()
                .importPackages("com.siemens.oam.template");

        ArchRule rule = noClasses().that()
                .resideInAPackage("..dataaccess..")
                .should().dependOnClassesThat().resideInAPackage("..service..");

        rule.check(importedClasses);
    }
    
}
