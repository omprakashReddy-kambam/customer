package com.siemens.oam.template.controller;

import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(CustomerController.class)
class CustomerControllerTest {

    @InjectMocks
    private CustomerController customerController;

    @MockBean
    private CustomerService customerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    void test_CreateCustomer() {
        CustomerDto customerDTO = new CustomerDto();
        when(customerService.createCustomer(customerDTO)).thenReturn(customerDTO);

        ResponseEntity<CustomerDto> response = customerController.createCustomer(customerDTO);

        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
        assertEquals(customerDTO, response.getBody());
        verify(customerService, times(1)).createCustomer(customerDTO);
    }

    @Test
    void test_getCustomerById(){
        UUID uuid=UUID.randomUUID();
        CustomerDto customerDTO = new CustomerDto();
        when(customerService.getCustomerById(uuid)).thenReturn(customerDTO);
        ResponseEntity<CustomerDto> response =customerController.getCustomerById(uuid);
//      assertEquals(HttpStatus.CREATED, response.getStatusCode());  //  if we mention status code type in
//                                                                       controller we need to enable this line
        assertEquals(customerDTO, response.getBody());
        verify(customerService,times(1)).getCustomerById(uuid);
    }

    @Test
    void test_getAllCustomers(){
       List<CustomerDto> allCustomers = new ArrayList<>();
        when(customerService.getAllCustomers()).thenReturn(allCustomers);
        ResponseEntity response=customerController.getAllCustomers();
        assertEquals(allCustomers,response.getBody());
        verify(customerService,times(1)).getAllCustomers();
    }

    @Test
    void test_deleteCustomer(){
        UUID uuid=UUID.randomUUID();
        CustomerDto customerDto=new CustomerDto();
        when(customerService.deleteCustomer(uuid)).thenReturn(customerDto);
        ResponseEntity response=customerController.deleteCustomer(uuid);
        assertEquals(customerDto,response.getBody());
        verify(customerService,times(1)).deleteCustomer(uuid);
    }

    @Test
    void test_updateCustomer(){
        CustomerDto customerDTO=new CustomerDto();
        when(customerService.updateCustomer(customerDTO)).thenReturn(customerDTO);
        ResponseEntity response=customerController.updateCustomer(customerDTO);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(customerDTO,response.getBody());
        verify(customerService,times(1)).updateCustomer(customerDTO);

    }
}
