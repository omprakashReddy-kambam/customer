package com.siemens.oam.template.repository;

import com.siemens.oam.template.dataaccess.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface TestH2Repository extends JpaRepository<Customer, UUID> {
}
