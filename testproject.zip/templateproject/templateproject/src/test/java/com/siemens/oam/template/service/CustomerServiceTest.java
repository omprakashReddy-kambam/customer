package com.siemens.oam.template.service;

import com.siemens.oam.template.dataaccess.entity.Customer;
import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


class CustomerServiceTest {
    @Mock
    private CustomerRepository customerRepository;
    @InjectMocks
    private CustomerService customerService;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    void test_createCustomer(){
        CustomerDto customerDto=new CustomerDto();
        when(customerRepository.save(any())).thenReturn(new Customer());
        CustomerDto createCustomer=customerService.createCustomer(customerDto);
        assertEquals(createCustomer,customerDto);
    }
    @Test
    void test_getCustomerById(){
        Customer customer=new Customer();
        UUID uuid=UUID.randomUUID();
        when(customerRepository.findById(uuid)).thenReturn(Optional.of(customer));
        CustomerDto customerDto=customerService.getCustomerById(uuid);
        assertEquals(CustomerDto.builder().build(),customerDto);
    }
    @Test
    void test_getCustomerByIdNotFound(){
        when(customerRepository.findById(UUID.randomUUID())).thenReturn(Optional.empty());
        CustomerDto customerDto=customerService.getCustomerById(UUID.randomUUID());
        assertNull(customerDto);
    }
    @Test
    void test_getAllCustomers() {
        List<Customer> customer = new ArrayList<>();
        when(customerRepository.findAll()).thenReturn(customer);
        List<CustomerDto> customerDto = customerService.getAllCustomers();
        assertNotNull(customerDto);
    }
    @Test
    void testDeleteCustomer() {
        UUID uuid = UUID.randomUUID();
        Customer customer = new Customer();
        when(customerRepository.findById(uuid)).thenReturn(Optional.of(customer));
        CustomerDto response = customerService.deleteCustomer(uuid);
        verify(customerRepository, times(1)).deleteById(uuid);
        assertThat(response);
    }
    @Test
    void test_deleteCustomerNotFound(){
        when(customerRepository.findById(UUID.randomUUID())).thenReturn(Optional.empty());
        CustomerDto customerDto=customerService.deleteCustomer(UUID.randomUUID());
        assertNull(customerDto);
    }
    @Test
    void test_updateCustomer(){
        Customer customer=new Customer();
        CustomerDto updatedCustomerDTO = new CustomerDto();
        when(customerRepository.findById(UUID.randomUUID())).thenReturn(Optional.of(customer));
        when(customerRepository.save(any(Customer.class))).thenAnswer(invocation -> {
            Customer savedEntity = invocation.getArgument(0);
            savedEntity.setName(updatedCustomerDTO.getName());
            savedEntity.setNumber(updatedCustomerDTO.getNumber());
            savedEntity.setEmail(updatedCustomerDTO.getEmail());
            return savedEntity;
        });
        assertEquals(updatedCustomerDTO, CustomerDto.builder().build());
    }

    @Test
    void test_updateCustomerNotFound(){
        CustomerDto updatedCustomerDTO = new CustomerDto();
        when(customerRepository.findById(UUID.randomUUID())).thenReturn(Optional.empty());
        when(customerRepository.save(any(Customer.class))).thenAnswer(invocation -> {
            Customer savedEntity = invocation.getArgument(0);
            savedEntity.setName(updatedCustomerDTO.getName());
            savedEntity.setNumber(updatedCustomerDTO.getNumber());
            savedEntity.setEmail(updatedCustomerDTO.getEmail());
            return savedEntity;
        });
        CustomerDto updatedCustomer = customerService.updateCustomer( updatedCustomerDTO);
        assertNull(updatedCustomer);
    }
}
