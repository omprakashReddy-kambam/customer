package com.siemens.oam.template.integation;


import com.siemens.oam.template.TemplateApplication;
//import com.siemens.oam.template.configaration.Operator;
import com.siemens.oam.template.dataaccess.entity.Customer;
import com.siemens.oam.template.dataaccess.entity.DataRequest;
import com.siemens.oam.template.dto.CustomerDto;
import com.siemens.oam.template.dto.PageResponseDto;
import com.siemens.oam.template.enums.Operator;
import com.siemens.oam.template.specifications.CompositeFilter;
import com.siemens.oam.template.specifications.JoinOperator;
import com.siemens.oam.template.specifications.SortDescriptor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT,
        classes = TemplateApplication.class)
 class CustomerDetailsFilterTest
        extends AbstractIntegrationTest {
    private final List<SortDescriptor> sort = List.of(new SortDescriptor("name", Sort.Direction.ASC));

    @BeforeEach
    public void setup() throws ParseException {
        customerRepository.save(Customer.builder().id(UUID.randomUUID()).name("aline").number("700000").email("aline@gmail.com").build());
    }
    @ParameterizedTest
    @ValueSource(
            strings = {
                    "name"
            })
    void customerDetailsFilter(String s) {
        CompositeFilter filter1 = new CompositeFilter();
        filter1.setField(s);
        filter1.setOperator(Operator.CONTAINS);
        filter1.setValue("aline");

        CompositeFilter compositeFilter1 = new CompositeFilter();
        compositeFilter1.setJoinOperator(JoinOperator.OR);
        compositeFilter1.setFilters(List.of(filter1));
        List<CompositeFilter> compositeFiltersTop = List.of(compositeFilter1);

        DataRequest dataRequest = new DataRequest(compositeFiltersTop,sort,0,30,new ArrayList<>());

        var responseEntity = executePostCustomerDetails(dataRequest);
        var responseBody = responseEntity.getBody();
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseBody.getTotalNumberOfElements()).isGreaterThanOrEqualTo(1);
        assertThat(responseBody.getTotalNumberOfPages()).isGreaterThanOrEqualTo(1);

    }
    private ResponseEntity<PageResponseDto<CustomerDto>> executePostCustomerDetails(DataRequest dataRequest) {
        return this.testrestTemplate.exchange(
                constructBaseUrl("filter/customer").build().toUriString(),
                HttpMethod.POST,
                new HttpEntity<>(dataRequest),
                new ParameterizedTypeReference<>() {
                });
    }
}
