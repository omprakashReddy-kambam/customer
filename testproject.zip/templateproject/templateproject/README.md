# Overview

The purpose of this application is to be as example for the future services, it shows the structure that 
new services should use and expose API.

# API

Postman project will be added in order to overview and use API

## Contract

The interaction is performed using REST services

# System requirements

* Java 11 - adoptopenjdk11
* Maven 3.8.2
* Spring Boot 2.5.1
* PostgreSQL 10.7

# How to run locally

1. Start a PostgreSQL database locally.
2. Create a new database.
3. Launch operation-manager

# How to run from Docker image

This requires to have Docker installed (of course).

## Using existing docker image

-- need artifactory

## Creating your own docker image

1. Build the image
   `docker build --tag=operation-manager:latest .`

2. Run the image
   ` docker run operation-manager`

   in the future there will be added also spring profiles.

You may specify other environment variables according your local setup, e.g:

`-e spring.datasource.url=jdbc:postgresql://localhost:5432/oam`

## Using docker-compose
1. to run both the service and database use
   `docker-compose up --build`
2. to stop
   `docker-compose down`
3. to stop and remove volumes
   `docker-compose down --rmi all --volumes`

